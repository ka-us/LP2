﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double IMC, Altura, Peso;

        public Form1()
        {
            InitializeComponent();
        }

        private void mktAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktAltura.Text, out Altura) || (Altura < 0))
            {
                MessageBox.Show("Altura inválida");
                Focus();
            }
        }

        private void mktPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktPeso.Text, out Peso) || (Peso < 0)) 
            {
                MessageBox.Show("Peso inválido");
                Focus();
            }
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            mktAltura.Clear();  
            mktPeso.Clear();
            txtIMC.Clear();
        }

        private void bntSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bntCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso/Math.Pow(Altura, 2);
            IMC = Math.Round(IMC,1);

            if (IMC < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (IMC >= 18.5 && IMC <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (IMC >= 25.0 && IMC <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (IMC >= 30.0 && IMC <= 39.9)
            {
                MessageBox.Show("Obesidade (Grau II)");
            }
            else // A última condição, maior ou igual a 40.0, pode ser tratada com um 'else'
            {
                MessageBox.Show("Obesidade Grave (Grau III)");
            }

            txtIMC.Text=IMC.ToString();

        }
    }
}
