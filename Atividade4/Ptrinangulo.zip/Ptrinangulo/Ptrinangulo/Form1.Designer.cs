﻿namespace Ptrinangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.mktC = new System.Windows.Forms.MaskedTextBox();
            this.mktB = new System.Windows.Forms.MaskedTextBox();
            this.mktA = new System.Windows.Forms.MaskedTextBox();
            this.btnCal = new System.Windows.Forms.Button();
            this.btnLim = new System.Windows.Forms.Button();
            this.bntSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(41, 60);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(60, 20);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Lado A";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(41, 148);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(60, 20);
            this.lblB.TabIndex = 1;
            this.lblB.Text = "Lado B";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(41, 234);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(60, 20);
            this.lblC.TabIndex = 2;
            this.lblC.Text = "Lado C";
            // 
            // mktC
            // 
            this.mktC.Location = new System.Drawing.Point(188, 234);
            this.mktC.Name = "mktC";
            this.mktC.Size = new System.Drawing.Size(100, 26);
            this.mktC.TabIndex = 3;
            this.mktC.Validated += new System.EventHandler(this.mktC_Validated);
            // 
            // mktB
            // 
            this.mktB.Location = new System.Drawing.Point(188, 142);
            this.mktB.Name = "mktB";
            this.mktB.Size = new System.Drawing.Size(100, 26);
            this.mktB.TabIndex = 2;
            this.mktB.Validated += new System.EventHandler(this.mktB_Validated);
            // 
            // mktA
            // 
            this.mktA.Location = new System.Drawing.Point(188, 60);
            this.mktA.Name = "mktA";
            this.mktA.Size = new System.Drawing.Size(100, 26);
            this.mktA.TabIndex = 1;
            this.mktA.Validated += new System.EventHandler(this.mktA_Validated);
            // 
            // btnCal
            // 
            this.btnCal.Location = new System.Drawing.Point(45, 309);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(109, 51);
            this.btnCal.TabIndex = 4;
            this.btnCal.Text = "Calcular";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // btnLim
            // 
            this.btnLim.Location = new System.Drawing.Point(280, 309);
            this.btnLim.Name = "btnLim";
            this.btnLim.Size = new System.Drawing.Size(97, 51);
            this.btnLim.TabIndex = 5;
            this.btnLim.Text = "Limpar";
            this.btnLim.UseVisualStyleBackColor = true;
            this.btnLim.Click += new System.EventHandler(this.btnLim_Click);
            // 
            // bntSair
            // 
            this.bntSair.Location = new System.Drawing.Point(465, 309);
            this.bntSair.Name = "bntSair";
            this.bntSair.Size = new System.Drawing.Size(82, 51);
            this.bntSair.TabIndex = 6;
            this.bntSair.Text = "Sair";
            this.bntSair.UseVisualStyleBackColor = true;
            this.bntSair.Click += new System.EventHandler(this.bntSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntSair);
            this.Controls.Add(this.btnLim);
            this.Controls.Add(this.btnCal);
            this.Controls.Add(this.mktA);
            this.Controls.Add(this.mktB);
            this.Controls.Add(this.mktC);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.MaskedTextBox mktC;
        private System.Windows.Forms.MaskedTextBox mktB;
        private System.Windows.Forms.MaskedTextBox mktA;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.Button btnLim;
        private System.Windows.Forms.Button bntSair;
    }
}

