﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptrinangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        private void mktA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktA.Text, out LadoA) || (LadoA < 0))
            {
                MessageBox.Show("Lado A inválido");
                Focus();
            }
        }

        private void mktB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktB.Text, out LadoB) || (LadoB < 0))
            {
                MessageBox.Show("Lado B inválido");
                Focus();
            }
        }

        private void mktC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktC.Text, out LadoC) || (LadoC < 0))
            {
                MessageBox.Show("Lado A inválido");
                Focus();
            }
        }

        private void btnLim_Click(object sender, EventArgs e)
        {
            mktA.Clear();
            mktB.Clear();
            mktC.Clear();
        }

        private void bntSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            if((LadoA > Math.Abs(LadoB - LadoC) && (LadoA < LadoB + LadoC))&& (LadoB > Math.Abs(LadoA - LadoC) && (LadoB < LadoA + LadoC))&& (LadoC > Math.Abs(LadoA - LadoB) && (LadoC < LadoA + LadoB)))
            {
                if (LadoA == LadoB && LadoB == LadoC)
                {
                    MessageBox.Show("Triangulo Equilatero");
                }
                else if ((LadoA == LadoB && LadoA != LadoC) || (LadoA == LadoC && LadoA != LadoB) || (LadoB == LadoC && LadoB != LadoA))
                {
                    MessageBox.Show("Triangulo Isóceles");
                }
                else if (LadoA != LadoB && LadoA != LadoC && LadoB != LadoC)
                {
                    MessageBox.Show("Triangulo Escaleno");

                }
            }
            else
            {
                MessageBox.Show("Algum lado invalido");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
