﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Quem não sabe fazer copia mesmo!!!");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cola aqui molecote");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();    
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio2"].BringToFront();
            }
            else
            {
                FrmExercicio2 fm2 = new FrmExercicio2();
                fm2.MdiParent = this;
                fm2.WindowState = FormWindowState.Minimized;
                fm2.Show();
            }


                FrmExercicio2 frm2 = new FrmExercicio2();
            frm2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio3"].BringToFront();
            }
            else
            {
                FrmExercicio3 fmr3 = new FrmExercicio3();
                fmr3.MdiParent = this;
                fmr3.WindowState = FormWindowState.Minimized;
                fmr3.Show();
            }


            FrmExercicio3 frm3 = new FrmExercicio3();
            frm3.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 fmr4 = new FrmExercicio4();
                fmr4.MdiParent = this;
                fmr4.WindowState = FormWindowState.Minimized;
                fmr4.Show();
            }


            FrmExercicio4 frm4 = new FrmExercicio4();
            frm4.Show();
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio5"].BringToFront();
            }
            else
            {
                FrmExercicio5 fm5 = new FrmExercicio5();
                fm5.MdiParent = this;
                fm5.WindowState = FormWindowState.Minimized;
                fm5.Show();
            }


            FrmExercicio5 frm5 = new FrmExercicio5();
            frm5.Show();
        }
    }
}
