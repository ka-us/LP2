﻿namespace Pmetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninverter = new System.Windows.Forms.Button();
            this.btnremove = new System.Windows.Forms.Button();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btninverter
            // 
            this.btninverter.Location = new System.Drawing.Point(436, 341);
            this.btninverter.Name = "btninverter";
            this.btninverter.Size = new System.Drawing.Size(192, 42);
            this.btninverter.TabIndex = 13;
            this.btninverter.Text = "Inverte 1º";
            this.btninverter.UseVisualStyleBackColor = true;
            this.btninverter.Click += new System.EventHandler(this.btninverter_Click);
            // 
            // btnremove
            // 
            this.btnremove.Location = new System.Drawing.Point(436, 293);
            this.btnremove.Name = "btnremove";
            this.btnremove.Size = new System.Drawing.Size(192, 42);
            this.btnremove.TabIndex = 12;
            this.btnremove.Text = "Remove 1º e 2º";
            this.btnremove.UseVisualStyleBackColor = true;
            this.btnremove.Click += new System.EventHandler(this.btnremove_Click);
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(492, 217);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 26);
            this.txtpalavra2.TabIndex = 10;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(492, 149);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 26);
            this.txtpalavra1.TabIndex = 9;
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(324, 217);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(70, 20);
            this.lblpalavra2.TabIndex = 8;
            this.lblpalavra2.Text = "Palavra2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(324, 143);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(70, 20);
            this.lblpalavra1.TabIndex = 7;
            this.lblpalavra1.Text = "Palavra1";
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 525);
            this.Controls.Add(this.btninverter);
            this.Controls.Add(this.btnremove);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btninverter;
        private System.Windows.Forms.Button btnremove;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
    }
}