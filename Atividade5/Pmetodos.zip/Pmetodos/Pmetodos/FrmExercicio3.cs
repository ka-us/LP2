﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void btninverter_Click(object sender, EventArgs e)
        {
            char[] vetor = txtpalavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            string auxiliar = new string(vetor);
            txtpalavra2.Text = auxiliar;
        }
    }
}
