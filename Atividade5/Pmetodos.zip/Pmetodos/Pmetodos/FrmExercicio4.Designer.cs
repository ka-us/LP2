﻿namespace Pmetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnnumcaract = new System.Windows.Forms.Button();
            this.btnbranco = new System.Windows.Forms.Button();
            this.btncontaletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(228, 22);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(423, 284);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnnumcaract
            // 
            this.btnnumcaract.Location = new System.Drawing.Point(52, 22);
            this.btnnumcaract.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnnumcaract.Name = "btnnumcaract";
            this.btnnumcaract.Size = new System.Drawing.Size(145, 46);
            this.btnnumcaract.TabIndex = 1;
            this.btnnumcaract.Text = "Caracteres numéricos";
            this.btnnumcaract.UseVisualStyleBackColor = true;
            this.btnnumcaract.Click += new System.EventHandler(this.btnnumcaract_Click);
            // 
            // btnbranco
            // 
            this.btnbranco.Location = new System.Drawing.Point(52, 90);
            this.btnbranco.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnbranco.Name = "btnbranco";
            this.btnbranco.Size = new System.Drawing.Size(145, 48);
            this.btnbranco.TabIndex = 2;
            this.btnbranco.Text = "1º carectere branco";
            this.btnbranco.UseVisualStyleBackColor = true;
            this.btnbranco.Click += new System.EventHandler(this.btnbranco_Click);
            // 
            // btncontaletras
            // 
            this.btncontaletras.Location = new System.Drawing.Point(52, 158);
            this.btncontaletras.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btncontaletras.Name = "btncontaletras";
            this.btncontaletras.Size = new System.Drawing.Size(145, 47);
            this.btncontaletras.TabIndex = 3;
            this.btncontaletras.Text = "Caracteres alfabeticos";
            this.btncontaletras.UseVisualStyleBackColor = true;
            this.btncontaletras.Click += new System.EventHandler(this.btncontaletras_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.btncontaletras);
            this.Controls.Add(this.btnbranco);
            this.Controls.Add(this.btnnumcaract);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnnumcaract;
        private System.Windows.Forms.Button btnbranco;
        private System.Windows.Forms.Button btncontaletras;
    }
}