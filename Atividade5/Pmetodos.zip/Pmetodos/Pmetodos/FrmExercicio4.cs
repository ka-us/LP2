﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnnumcaract_Click(object sender, EventArgs e)
        {
            {
                int contaNum = 0;
                int posicao = 0;

                while (posicao < rchtxtFrase.Text.Length)
                {
                    if (Char.IsNumber(rchtxtFrase.Text[posicao]))
                    {
                        contaNum++;
                    }
                    posicao++;
                }
                MessageBox.Show($"O texto tem {contaNum} números");


            }
        }

        private void btnbranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"O 1º caracter branco está na posição {i+1}");
                    break;
                }
            }
        }

        private void btncontaletras_Click(object sender, EventArgs e)
        {
            int contletra = 0;
            foreach (char c in rchtxtFrase.Text)
            {            
                if(char.IsLetter(c))
                {
                    contletra++;
                }
            }

            MessageBox.Show($"O texto contém {contletra} números");
        }
    }
}
