﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio5 : Form
    {
        private readonly Random random = new Random();
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtNumero1.Text, out int numero1) || !int.TryParse(txtNumero2.Text, out int numero2))
            {
                MessageBox.Show("Insira números válidos");
                return;
            }
            if(numero1>=numero2 )
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo!");
                return;
            }
            int sorteio = random.Next(numero1,numero2+1);

            MessageBox.Show($"O número sorteado é {sorteio}");
        }
    }
}
