﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio2 : Form
    {
        string palavra1;
        string palavra2;

        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            palavra1 = txtpalavra1.Text.Trim();
            palavra2 = txtpalavra2.Text.Trim();

            int resultado = String.Compare(palavra1, palavra2, StringComparison.OrdinalIgnoreCase);

            if (resultado == 0)
            {
                MessageBox.Show("As palavras são iguais");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes");
            }
        }

        private void btninserir1_Click(object sender, EventArgs e)
        {
            palavra1 = txtpalavra1.Text;
            palavra2 = txtpalavra2.Text;

            int meiopalavra2 = palavra2.Length / 2;
            string parte1 = palavra2.Substring(0, meiopalavra2);
            string parte2 = palavra2.Substring(meiopalavra2);

            string novapalavra = parte1 + palavra1 + parte2;
            txtpalavra2.Text = novapalavra;
        }

        private void btninserir2_Click(object sender, EventArgs e)
        {
            palavra1 = txtpalavra1.Text;
            palavra2 = txtpalavra2.Text;

            int meiopalavra2 = palavra1.Length / 2;
            string parte1 = palavra1.Substring(0, meiopalavra2);
            string parte2 = palavra1.Substring(meiopalavra2);

            string novapalavra = parte1 + "**" + parte2;
            txtpalavra2.Text = novapalavra;
        }
    }
}
