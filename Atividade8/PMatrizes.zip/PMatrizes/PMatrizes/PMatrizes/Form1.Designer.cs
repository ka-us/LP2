﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnex1 = new System.Windows.Forms.Button();
            this.btnex2 = new System.Windows.Forms.Button();
            this.btnex3 = new System.Windows.Forms.Button();
            this.btnex4 = new System.Windows.Forms.Button();
            this.btnex5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnex1
            // 
            this.btnex1.Location = new System.Drawing.Point(282, 39);
            this.btnex1.Name = "btnex1";
            this.btnex1.Size = new System.Drawing.Size(200, 150);
            this.btnex1.TabIndex = 0;
            this.btnex1.Text = "Exercicio 1";
            this.btnex1.UseVisualStyleBackColor = true;
            this.btnex1.Click += new System.EventHandler(this.btnex1_Click);
            // 
            // btnex2
            // 
            this.btnex2.Location = new System.Drawing.Point(688, 39);
            this.btnex2.Name = "btnex2";
            this.btnex2.Size = new System.Drawing.Size(200, 150);
            this.btnex2.TabIndex = 1;
            this.btnex2.Text = "Exercicio 2";
            this.btnex2.UseVisualStyleBackColor = true;
            this.btnex2.Click += new System.EventHandler(this.btnex2_Click);
            // 
            // btnex3
            // 
            this.btnex3.Location = new System.Drawing.Point(282, 286);
            this.btnex3.Name = "btnex3";
            this.btnex3.Size = new System.Drawing.Size(200, 150);
            this.btnex3.TabIndex = 2;
            this.btnex3.Text = "Exercicio 3";
            this.btnex3.UseVisualStyleBackColor = true;
            this.btnex3.Click += new System.EventHandler(this.btnex3_Click);
            // 
            // btnex4
            // 
            this.btnex4.Location = new System.Drawing.Point(688, 297);
            this.btnex4.Name = "btnex4";
            this.btnex4.Size = new System.Drawing.Size(200, 150);
            this.btnex4.TabIndex = 3;
            this.btnex4.Text = "Exercicio 4";
            this.btnex4.UseVisualStyleBackColor = true;
            this.btnex4.Click += new System.EventHandler(this.btnex4_Click);
            // 
            // btnex5
            // 
            this.btnex5.Location = new System.Drawing.Point(482, 483);
            this.btnex5.Name = "btnex5";
            this.btnex5.Size = new System.Drawing.Size(200, 150);
            this.btnex5.TabIndex = 4;
            this.btnex5.Text = "Exercicio 5";
            this.btnex5.UseVisualStyleBackColor = true;
            this.btnex5.Click += new System.EventHandler(this.btnex5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 661);
            this.Controls.Add(this.btnex5);
            this.Controls.Add(this.btnex4);
            this.Controls.Add(this.btnex3);
            this.Controls.Add(this.btnex2);
            this.Controls.Add(this.btnex1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnex1;
        private System.Windows.Forms.Button btnex2;
        private System.Windows.Forms.Button btnex3;
        private System.Windows.Forms.Button btnex4;
        private System.Windows.Forms.Button btnex5;
    }
}

