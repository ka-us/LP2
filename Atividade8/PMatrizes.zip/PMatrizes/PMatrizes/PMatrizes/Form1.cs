﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        string auxiliar;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnex1_Click(object sender, EventArgs e)
        {
            auxiliar = string.Empty;
            int[] vetor = new int[20];

            for(int i = 0;i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o Nº{i+1}", "Entrada de Dados");

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnex2_Click(object sender, EventArgs e)
        {
            auxiliar = string.Empty;
            ArrayList lista = new ArrayList(){"Ana", "André", "Beatriz", "Camila", "João","Joana", "Otávio", "Marcelo", "Pedro", "Thais"};
            lista.Remove("Otávio");

            foreach(string nome in lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnex3_Click(object sender, EventArgs e)
        {
            auxiliar = string.Empty;
            double[,] notas= new double[20, 3];
            auxiliar = "";
            double media = 0;
            string saida = "";
            for(int i = 0; i < 20; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno{i + 1}", "Entrada de dados");
                    if(!double.TryParse(auxiliar, out notas[i,j]) || notas[i,j] < -1 || notas[i,j] > 11)
                    {
                        MessageBox.Show("Dado inválido!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                saida += $"Aluno: {i + 1} média {media / 3}";
                media = 0;
                MessageBox.Show(saida);
            }
        }

        private void btnex4_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.Show();
            }
        }

        private void btnex5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.Show();
            }
        }
    }
}