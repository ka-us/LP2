﻿namespace PMatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnverificar = new System.Windows.Forms.Button();
            this.lbx = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(47, 153);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(200, 100);
            this.btnverificar.TabIndex = 0;
            this.btnverificar.Text = "Verificar";
            this.btnverificar.UseVisualStyleBackColor = true;
            this.btnverificar.Click += new System.EventHandler(this.btnverificar_Click);
            // 
            // lbx
            // 
            this.lbx.FormattingEnabled = true;
            this.lbx.ItemHeight = 20;
            this.lbx.Location = new System.Drawing.Point(300, 33);
            this.lbx.Name = "lbx";
            this.lbx.Size = new System.Drawing.Size(462, 384);
            this.lbx.TabIndex = 1;
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbx);
            this.Controls.Add(this.btnverificar);
            this.Name = "frmExercicio5";
            this.Text = "Exercicio 5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.ListBox lbx;
    }
}