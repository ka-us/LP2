﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        private readonly char[] vetGabaritoRespostas = { 'A', 'D', 'C', 'B', 'E', 'A', 'B', 'D', 'C', 'E' };
        private const int INT_NUM_ALUNOS = 2;
        private const int INT_NUM_QUESTOES = 10;
        private char[,] mtxRespostasAlunos = new char[INT_NUM_ALUNOS, INT_NUM_QUESTOES];
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            lbx.Items.Clear();

            for (int intAluno = 0; intAluno < INT_NUM_ALUNOS; intAluno++)
            {
                int intAcertos = 0;
                lbx.Items.Add($"Aluno {intAluno + 1}:");

                for (int intQuestao = 0; intQuestao < INT_NUM_QUESTOES; intQuestao++)
                {
                    string strRespostaEntrada;
                    bool blnRespostaValida = false;

                    do
                    {
                        // Recebe a resposta do aluno via InputBox
                        strRespostaEntrada = Interaction.InputBox(
                            $"Digite a resposta para o Aluno {intAluno + 1}, Questão {intQuestao + 1} (A, B, C, D ou E):",
                            "Entrada de Resposta",
                            ""
                        );

                        // Normaliza a resposta para maiúscula e verifica se é válida
                        if (!string.IsNullOrEmpty(strRespostaEntrada))
                        {
                            strRespostaEntrada = strRespostaEntrada.ToUpper();

                            if (strRespostaEntrada.Length == 1 && "ABCDE".Contains(strRespostaEntrada))
                            {
                                blnRespostaValida = true;
                            }
                            else
                            {
                                // Se a resposta for inválida, força a correção
                                MessageBox.Show(
                                    "Resposta inválida. Por favor, digite apenas uma letra (A, B, C, D ou E).",
                                    "Erro de Entrada",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning
                                );
                            }
                        }
                        else
                        {
                            // Trata o caso de campo vazio ou Cancelar
                            MessageBox.Show(
                                "A resposta não pode ser vazia. Por favor, insira A, B, C, D ou E.",
                                "Erro de Entrada",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning
                            );
                        }
                    } while (!blnRespostaValida);

                    char chrRespostaAluno = strRespostaEntrada[0];
                    mtxRespostasAlunos[intAluno, intQuestao] = chrRespostaAluno;

                    // Compara com o Gabarito
                    if (chrRespostaAluno == vetGabaritoRespostas[intQuestao])
                    {
                        intAcertos++;
                        lbx.Items.Add($"  Q{intQuestao + 1}: Correta ({chrRespostaAluno})");
                    }
                    else
                    {
                        lbx.Items.Add($"  Q{intQuestao + 1}: Incorreta ({chrRespostaAluno} - Gabarito: {vetGabaritoRespostas[intQuestao]})");
                    }
                }

                // Exibe o total de acertos
                lbx.Items.Add($"Total de Acertos do Aluno {intAluno + 1}: {intAcertos} de {INT_NUM_QUESTOES}");
                lbx.Items.Add("------------------------------------");
            }
        }
    }
}
