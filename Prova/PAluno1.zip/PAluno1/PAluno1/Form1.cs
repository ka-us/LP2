﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            string auxiliar;
            double[,] notas = new double[5, 3];
            auxiliar = "";
            double media = 0, med;
            
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {i + 1} com o professor {j+1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado inválido!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                med = media / 3;
                med = Math.Round(med, 2);
                lbx.Items.Add($"Aluno {i + 1} Nota Professor 1: {notas[i, 0]}  Nota Professor 2: {notas[i, 1]}  Nota Professor 3:{notas[i, 2]}  Media: {med}");
                lbx.Items.Add("-------------------------------------------------------------------------------------------------------------------------------------------------");
                media = 0;
                med = 0;
            }

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            lbx.Items.Clear();
        }
    }
}
