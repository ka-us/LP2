﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] comprimentos = new int[10];

            lbx.Items.Clear();

            for(int i = 0;i<10;i++)
            {
                string nomeCompleto;
                bool entradaValida = false;

                while(!entradaValida)
                {
                    string prompt = $"Digite o nome completo da {i + 1}ª de 10 pessoas:";
                    string titulo = "Carregamento de Nomes";

                    nomeCompleto = Interaction.InputBox(prompt, titulo, "");

                    if (string.IsNullOrEmpty(nomeCompleto))
                    {
                        DialogResult resultado = MessageBox.Show(
                            "O nome não pode ser vazio. Deseja cancelar o carregamento?",
                            "Aviso",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (resultado == DialogResult.Yes)
                        {
                            return; 
                        }
                    }
                    else
                    { 
                    nomes[i] = nomeCompleto;

                        string nomeSemEspacos = nomeCompleto.Replace(" ", "");
                        int tamanho = nomeSemEspacos.Length;

                        comprimentos[i] = tamanho;

                        entradaValida = true; 
                    }

                }
            }
            MessageBox.Show("Carregamento concluído. Exibindo resultados no ListBox.", "Sucesso");

            for (int i = 0; i < 10; i++)
            {
                string itemListBox = $"{nomes[i]} (Comprimento sem espaços: {comprimentos[i]} caracteres)";
                lbx.Items.Add(itemListBox);
            }
        }
    }
}
